from flask_login import UserMixin

from flask import session
from database import obter_conexao

class User(UserMixin):
    email: str
    def __init__(self, nome, senha):
        self.nome = nome
        self.senha = senha

    @classmethod
    def get(cls, user_id):
        # conexao = sqlite3.connect('banco.db')
        # conexao.row_factory = sqlite3.Row
        conexao = obter_conexao()
        sql = "SELECT * FROM users WHERE email = ?"
        resultado = conexao.execute(sql, (user_id,) ).fetchone()
        user = User(nome=resultado['email'], senha=resultado['senha'])
        user.id = resultado['email']
        return user

    @classmethod
    def all(cls):
        return session.get('usuarios')

    @classmethod
    def find_email(cls, email):
        pass

    def save(self):
        lista_usuarios = session.get('usuarios')
        lista_usuarios[self.nome] = self.senha
        session['usuarios'] = lista_usuarios

    @classmethod
    def delete(cls, email):
        lista_usuarios = session.get('usuarios')
        lista_usuarios.pop(email)
        session['usuarios'] = lista_usuarios
